package com.example.real_time_vehicle_tracking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
